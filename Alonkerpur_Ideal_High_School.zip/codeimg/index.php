 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>
    <script src="https://kit.fontawesome.com/64340c05bf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Upload Image</title>
    <link rel="stylesheet" href="CSS/owl.carousel.min.css">
<link rel="stylesheet" href="result.css">
    <link rel="stylesheet" href="style.css">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>
    <script src="https://kit.fontawesome.com/64340c05bf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/owl.carousel.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto&family=Source+Sans+3:ital,wght@0,200;0,300;0,400;0,500;0,700;1,200;1,300;1,500;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="about.css">

    <link rel="stylesheet" href="style.css">
    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>
    <script src="https://kit.fontawesome.com/64340c05bf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/owl.carousel.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto&family=Source+Sans+3:ital,wght@0,200;0,300;0,400;0,500;0,700;1,200;1,300;1,500;1,800;1,900&display=swap"
        rel="stylesheet">
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>
    <script src="https://kit.fontawesome.com/64340c05bf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/owl.carousel.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto&family=Source+Sans+3:ital,wght@0,200;0,300;0,400;0,500;0,700;1,200;1,300;1,500;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="about.css">

    <link rel="stylesheet" href="style.css">

    <head>
        <style>
            /* Style for the dropdown container */
            .dropdown {
                position: relative;
                display: inline-block;
            }

            /* Style for the dropdown menu */
            .dropdown-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background-color: #f1f1f1;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
                z-index: 1;
            }

            /* Style for the dropdown item links */
            .dropdown-menu a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

            /* Change the link color on hover */
            .dropdown-menu a:hover {
                background-color: #ddd;
            }

            /* Show the dropdown menu when hovering over the dropdown container */
            .dropdown:hover .dropdown-menu {
                display: block;
            }
        </style>
        <style>
            div.example {
                background-color: rgb(51, 61, 205);
                padding: 10px;
            }

            @media screen and (min-width: 601px) {
                div.example {
                    font-size: 80px;
                }
            }

            @media screen and (max-width: 500px) {
                div.example {
                    font-size: 30px;
                }
            }
        </style>
    </head>

<body>




    <section style="background-color: gray; padding: 20px;" class="container  bg-primary">
        <div class="container example">
            <div class="row">
                <div class="col-md-3  d-flex    ">
                    <div class="logo-img  ">
                        <img src="images/logo (2).png" alt="" width="75%" class="text-center">
                    </div>
                </div>
                <div class="col-md-6 ">
                    <div class="hader text-light fw-bold ">

                        <h2 class="">অলংকার পুর আদর্শ মাধ্যমিক বিদ্যালয়</h2>
                        <h4 class="text-center">বালিয়াকান্দি, রাজবাড়ী</h4>
                    </div>
                </div>
                <div class="col-md-3 justify-content-end d-flex     ">
                    <div class="logo-img  ">
                        <img src="images/logo (2).png" alt="" width="75%" class="text-center">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- header section end -->

    <section class="container bg-success">

        <marquee behavior="" direction="" class="fw-bold text-uppercase text-black mt-2 ">মাধ্যমিক ও উচ্চমাধ্যমিক শিক্ষা
            অধিদপ্তর ফলাফল ২০২৩ প্রকাশিত হয়েছে সম্প্রীতি কিছু সময় আগে। যারা এই অধিদপ্তরে চাকরির জন্য পরীক্ষা
            দিয়েছিলেন তাদের চূড়ান্ত রেজাল্ট প্রকাশিত হয়েছে। যে সকল প্রার্থীরা ফলাফল দেখতে ইচ্ছুক তারা আমাদের
            আর্টিকেলটি পূরণ এবং ফলাফল দেখে নিন এখন।</marquee>
    </section>
    <!--marquee section s end -->


    <!-- navbar section start -->
    <section class="container">
        <nav class="navbar navbar-expand-sm navbar-dark text-primary bg-secondary navbar-sticky-top">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse text-primary" id="mynavbar">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">

                            <button class="  btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary active" href="http://127.0.0.1:5500/index.html">HOME</a>

                            </button>

                        </li>
                        <li class="nav-item">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary" href="http://127.0.0.1:5500/about.html">ABOUT US</a>

                            </button>
                        </li>
                        <li class="nav-item dropdown">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary dropdown-toggle" data-bs-toggle="dropdown"
                                    href="#">STUDENT CORNER</a>

                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/student.html">Our Student</a> </li>
                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/Notic/notic1.html">Feesh
                                        pyment</a> </li>

                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/student/dress.html">Dress
                                        info</a></li>
                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/student/rutting.html">Class
                                        Rutting</a></li>
                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/student/rutting.html">Exam Rutting</a></li>
                                <li><a class="dropdown-item" href="http://127.0.0.1:5500/attentends.html">Attentends </a></li>

                            </ul>
                        </li>
                        <li class="nav-item">
                            <button class="btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary"
                                    href="http://localhost/Alonkerpur_Ideal_High_School/codeimg/index.php">RESULTS</a>

                            </button>

                        </li>
                        <li class="nav-item">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary" href="http://127.0.0.1:5500/galary.html">GALLERY</a>


                            </button>
                        </li>
                        <li class="nav-item">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary" href="http://127.0.0.1:5500/contact.html">CONTACT</a>

                            </button>
                        </li>
                        <li class="nav-item">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary"
                                    href="http://127.0.0.1:5500/Notic/notic1.html">PYMENT</a>

                            </button>
                        </li>
                        <li class="nav-item">
                            <button class=" btn-outline-dark">
                                <a class="nav-link  fw-bold text-primary" href="http://127.0.0.1:5500/techers.html">TECHERS</a>

                            </button>
                        </li>




                    </ul>
                    <form class="action_page.php d-flex">

                        <a href="#mymodel" class="btn btn-primary me-2" data-bs-toggle="modal">Log-In</a>
                        <a href="#mymode2" data-bs-toggle="modal" class="btn btn-primary">Sign-Up</a>
                    </form>
                </div>
            </div>
        </nav>
    </section>
    <!-- navbar section start -->
   

      
 <section style="background-image: url()" class="container massage">
   <div class="container">
   <div class="alert alert-secondary" role="alert">
        <h4 class="text-center">Result vidw section</h4>
    </div>
    <div class="container col-12 m-5">
       <div class="col-6 m-auto">

        <?php
      if(isset($_POST['btn_img']))
      {
        $con = mysqli_connect("localhost","root","","codeaddict");

        $filename = $_FILES["choosefile"]["name"];
        $tempfile = $_FILES["choosefile"]["tmp_name"];
        $folder = "image/".$filename;
        $sql = "INSERT INTO `images`(`image`)VALUES('$filename')";
        if($filename == "")
        {
            echo 
            "
            <div class='alert alert-danger' role='alert'>
                <h4 class='text-center'>Blank not Allowed</h4>
            </div>
            ";
        }else{
            $result = mysqli_query($con, $sql);
            move_uploaded_file($tempfile, $folder);
            echo 
            "
            <div class='alert alert-success' role='alert'>
                <h4 class='text-center'>Image uploaded</h4>
            </div>
            ";
        }
      }

        
        ?>
     
      <div class=" ">
        <div class="row justify-content-cetner ">
            <div class="col-lg-12 col-md-6 col-sm-3">
            <form  action="index.php" method="post" class="form-control result" enctype="multipart/form-data">
            <input type="file" class="form-control" name="choosefile"  id="">
            <div class="col-6 m-auto ">
                <button type="submit" name="btn_img" class="btn btn-outline-success m-4">
                Submit
            </button>
            </div>
        </form>
            </div>
        </div>
      </div>











         <!-- <form  action="index.php" method="post" class="form-control result" enctype="multipart/form-data">
            <input type="file" class="form-control" name="choosefile"  id="">
            <div class="col-6 m-auto ">
                <button type="submit" name="btn_img" class="btn btn-outline-success m-4">
                Submit
            </button>
            </div>
        </form> -->

        <table class=" ">
            <tr>
                <th>id</th>
                <th>our result section</th>
                <th>button</th>

            </tr>

            <?php
            $conn = mysqli_connect("localhost","root","","codeaddict");
            $sql2 = "SELECT*FROM `images` WHERE 1";
            $result2 = mysqli_query($conn, $sql2);
            while($fetch = mysqli_fetch_assoc($result2))
            {
                echo "";

                ?>

                <tr>
                    <td><?php echo $fetch['id'] ?></td>
                    <td><img src="./image/<?php echo $fetch['image'] ?>" height="520px" width=420px alt=""></td> 
                  
                    <td><a href="delete.php?id=<?php echo $fetch['id'] ?>" class="btn btn-outline-danger">Delete</a></td>
                </tr>



                <?php
                "";
            } 
            ?>
        </table>

     


       </div>
    </div>

   </div>
   
   </section>
    
   
       
     <!-- Remove the container if you want to extend the Footer to full width. -->
     <div class="container  justify-content-center text-center mt-4 ">

<footer style="background-color: #99a6f0;">
    <div class="container footer p-4">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="mb-3" style="letter-spacing: 2px; color: #7f4722;">ALONGKERPUR IDEAL HIGH SCHOOL</h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;"> Baliakindi,Rajbari</a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">Mob:01778187601</a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">school0@gmail.com</a>
                    </li>
                    <li>
                        <a href="#!" style="color: #4f4f4f;"> location 12/4004 </a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="mb-3" style="letter-spacing: 2px; color: #7f4722;">OPENNING DAY</h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">
                            SUNDAY


                        </a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">MONDAY</a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;"> TUESDAY</a>
                    </li>
                    <li>
                        <a href="#!" style="color: #4f4f4f;"> WEDNESDAY </a>
                    </li>
                    <li>
                        <a href="#!" style="color: #4f4f4f;"> THURSDAY </a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="mb-3" style="letter-spacing: 2px; color: #7f4722;"> COLOGEING DAY </h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;"> FRIDAY
                        </a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;"> SATURDAY </a>
                    </li>

                </ul>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="mb-3" style="letter-spacing: 2px; color: #7f4722;">OTHER ACTIVITY</h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">registration</a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">application</a>
                    </li>
                    <li class="mb-1">
                        <a href="#!" style="color: #4f4f4f;">about program</a>
                    </li>
                    <li>
                        <a href="#!" style="color: #4f4f4f;">SUBSCRIBE</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Copyright -->
</footer>

</div>
<!-- End of .container -->
    


    

    <script src="JS/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="JS/owl.carousel.min.js"></script>


</body>

</html>